//
//  main.m
//  Matchismo
//
//  Created by Doug Lewis on 3/12/13.
//  Copyright (c) 2013 razorfish. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CardGameAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CardGameAppDelegate class]));
    }
}
