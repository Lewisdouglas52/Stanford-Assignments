//
//  CardGameViewController.m
//  Matchismo
//
//  Created by Doug Lewis on 3/12/13.
//  Copyright (c) 2013 razorfish. All rights reserved.
//

#import "CardGameViewController.h"
#import "PlayingCardDeck.h"
#import "CardMatchingGame.h"

@interface CardGameViewController ()
@property (weak, nonatomic) IBOutlet UILabel *flipsLabel;
@property (nonatomic) int flipCount;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;
@property (strong, nonatomic) CardMatchingGame *game;
@property (weak, nonatomic) IBOutlet UILabel *scoreLabel;
@property (weak, nonatomic) IBOutlet UILabel *discriptionLabel;
@property (weak, nonatomic) IBOutlet UISegmentedControl *matchSelector;
@end

@implementation CardGameViewController


- (CardMatchingGame *)game {
    if(!_game) _game = [[CardMatchingGame alloc] initWithCardCount:[self.cardButtons count]
                                                         usingDeck:[[PlayingCardDeck alloc] init]];
    
    return _game;
}


- (void)setCardButtons:(NSArray *)cardButtons {
    _cardButtons = cardButtons;
    [self updateUI];
}

- (void)updatediscription {
    NSString *discription = @"";
    int lastScore = [self.game lastScore];
    NSString *matchedCardsAsString = [[self.game lastMatch] componentsJoinedByString:@" & "];
    Card* lastFlippedCard = [self.game lastCard];
    
    if (matchedCardsAsString) {
        if (lastScore > 0) {
            discription = [NSString stringWithFormat:@"Matched %@ for %d points", matchedCardsAsString, lastScore];
        } else if (lastScore < 0) {
            discription = [NSString stringWithFormat:@"%@ don't match! %d point penalty!", matchedCardsAsString, -lastScore];
        }
    } else {
        if (lastFlippedCard) {
            discription = [NSString stringWithFormat:@"Flipped up %@", lastFlippedCard];
        } else {
            discription = @"Ready!!";
        }
    }
    
    
    self.discriptionLabel.text = discription;
}

- (void)updateUI {
    UIImage *cardBackImage = [UIImage imageNamed:@"white_apple_logo.jpg"];
    for (UIButton *cardButton in self.cardButtons) {
        Card *card = [self.game cardAtIndex:[self.cardButtons indexOfObject:cardButton]];
        [cardButton setTitle:card.contents forState:UIControlStateSelected];
        [cardButton setTitle:card.contents forState:UIControlStateSelected|UIControlStateDisabled];
        
        cardButton.selected = card.isFaceUp;
        cardButton.enabled = !card.isUnplayable;
        cardButton.alpha = card.isUnplayable ? 0.3: 1.0;
        
        if (!card.isFaceUp) {
            [cardButton setBackgroundImage:cardBackImage forState:UIControlStateNormal];
        }
        else{
            [cardButton setBackgroundImage:nil forState:UIControlStateNormal];
        }
    
    }
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %d", self.game.score];
    [self updatediscription];
}

-(void)setFlipCount:(int)flipCount {
    _flipCount = flipCount;
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d", self.flipCount];
}

- (IBAction)flipCard:(UIButton *)sender {
    if (self.matchSelector.isEnabled) {
        self.game.cardsToMatch = [self numCardsToMatch:self.matchSelector.selectedSegmentIndex];
        self.matchSelector.enabled = NO;
    }
    
    [self.game flipCardAtIndex:[self.cardButtons indexOfObject:sender]];
    self.flipCount++;
    [self updateUI];
}
- (IBAction)newGame:(id)sender {
    self.game = nil;
    self.matchSelector.enabled = YES;
    self.flipCount = 0;
    [self updateUI];
}

- (int)numCardsToMatch:(NSUInteger)index {
    return index + 2;
}

@end
