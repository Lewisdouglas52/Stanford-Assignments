//
//  Card.m
//  Matchismo
//
//  Created by Doug Lewis on 3/12/13.
//  Copyright (c) 2013 razorfish. All rights reserved.
//

#import "Card.h"

@implementation Card

- (int)match:(NSArray *)otherCards{
    
    int score =0;
    
    for (Card *card in otherCards) {
    
        if ([card.contents isEqualToString:self.contents]){
            score = 1;
        }
    }
    return score;
    
}

@end
