//
//  CardMatchingGame.m
//  Matchismo
//
//  Created by Doug Lewis on 3/12/13.
//  Copyright (c) 2013 razorfish. All rights reserved.
//

#import "CardMatchingGame.h"

@interface CardMatchingGame()
@property (strong, nonatomic) NSMutableArray *cards;
@property (nonatomic, readwrite) int score;
@property (nonatomic, readwrite) int lastScore;
@property (nonatomic, readwrite) Card* lastCard;
@property (nonatomic, readwrite) NSArray* lastMatch;
@property (nonatomic) NSMutableArray* matchedCardsList;
@end

@implementation CardMatchingGame

- (NSMutableArray *)cards {
    if(!_cards) _cards = [[NSMutableArray alloc] init];
    return _cards;
}

- (NSMutableArray *)matchedCardsList {
    if(!_matchedCardsList) _matchedCardsList = [[NSMutableArray alloc] init];
    
    return _matchedCardsList;
}

- (id)initWithCardCount:(NSUInteger)count usingDeck:(Deck *)deck {
    self = [super init];
    
    if (self) {
        for (int i = 0; i < count; i++) {
            Card *card = [deck drawRandomCard];
            if (!card) {
                self = nil;
                break;
            } else {
                self.cards[i] = card;
            }
        }
    }
    
    self.cardsToMatch = 2;
    
    return self;
}

- (Card *)cardAtIndex:(NSUInteger)index {
    return (index < self.cards.count) ? self.cards[index] : nil;
}

#define FLIP_COST 1
#define MATCH_BONUS 4
#define MISMATCH_PENALTY 2

- (void)flipCardAtIndex:(NSUInteger)index {
    Card *card = [self cardAtIndex:index];
    self.lastCard = nil;
    self.lastMatch = nil;
    self.lastScore = 0;
    
    if (!card.isUnplayable) {
        if (!card.isFaceUp) {
            self.lastCard = card;
            [self.matchedCardsList addObject:card];
            if ([self.matchedCardsList count] == self.cardsToMatch) {
                [self finalizeTurnScore];
            }
            self.score -=FLIP_COST;
        } else {
            [self.matchedCardsList removeObject:card];
        }
        card.faceUp = !card.isFaceUp;
    }
}

- (void)finalizeTurnScore {
    self.lastMatch = [self.matchedCardsList copy];
    
    Card* card = [self.matchedCardsList lastObject];
    [self.matchedCardsList removeLastObject];
    
    int matchScore = [card match:self.matchedCardsList];
    if (matchScore) {
        for (Card* otherCard in self.matchedCardsList) {
            otherCard.unplayable = YES;
        }
        card.unplayable = YES;
        self.lastScore = matchScore * MATCH_BONUS;
        self.matchedCardsList = nil;
    } else {
        for (Card* otherCard in self.matchedCardsList) {
            otherCard.faceUp = NO;
        }
        self.lastScore = -MISMATCH_PENALTY;
        self.matchedCardsList = nil;
        [self.matchedCardsList addObject:card];
    }
    self.score += self.lastScore;
}

@end
