//
//  ScoresViewController.h
//  Matchismo II
//
//  Created by Doug Lewis on 20/02/13.
//  Copyright (c) 2013 Twicecraft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoresViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *scoresDetail;
@end
