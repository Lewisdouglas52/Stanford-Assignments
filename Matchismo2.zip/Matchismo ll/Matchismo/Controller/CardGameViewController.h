//
//  CardGameViewController.h
//  Matchismo
//
//  Created by Doug Lewis on 3/13/2013
//  Copyright (c) 2013 Twicecraft. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CardMatchingGame.h"
#import "CardGameScore.h"

/* Public Interface */
@interface CardGameViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *flipsLabel;
@property (nonatomic) int flipCount;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;
@property (strong, nonatomic) CardMatchingGame *game;
@property (weak, nonatomic) IBOutlet UILabel *scoreLabel;
@property (weak, nonatomic) IBOutlet UILabel *DesscriptionLabel;
@property (strong, nonatomic) UIImage* cardBackImage;
@property (nonatomic) NSUInteger flipCost;
@property (nonatomic) NSUInteger matchBonus;
@property (nonatomic) NSUInteger mismatchPenalty;
@property (nonatomic) NSUInteger cardsToMatch;
@property (nonatomic, strong) Deck* deck;
@property (strong, nonatomic) NSString* currentDesscription;
@property (strong, nonatomic) NSString* typeOfGame;
@property (strong, nonatomic) CardGameScore *cardGameScore;
@end

