//
//  CardGameViewController.m
//  Matchismo
//
//  Created by Doug Lewis on 3/13/2013
//  Copyright (c) 2013 Twicecraft. All rights reserved.
//

#import "CardGameViewController.h"
#import "PlayingCardDeck.h"




@implementation CardGameViewController
- (CardMatchingGame *)game {
    if(!_game) _game = [[CardMatchingGame alloc] initWithCardCount:[self.cardButtons count]
                                                         usingDeck:self.deck
                                                      withFlipCost:self.flipCost
                                                        matchBonus:self.matchBonus
                                                   mismatchPenalty:self.mismatchPenalty
                                                      cardsToMatch:self.cardsToMatch];
    
    return _game;
}

- (CardGameScore *)cardGameScore {
    if (!_cardGameScore) _cardGameScore = [[CardGameScore alloc] initWithCardMatchingGame:self.game typeOfGame:self.typeOfGame];
    
    return _cardGameScore;
}

- (UIImage *)cardBackImage {
    if (!_cardBackImage) _cardBackImage = [UIImage imageNamed:@"white_apple_logo.jpg"];
    
    return _cardBackImage;
}


- (void)setCardButtons:(NSArray *)cardButtons {
    _cardButtons = cardButtons;
    [self updateUI];
}

- (void)updateButtonsAndLabels {}

- (NSString *)getDesscriptionForCurrentGame {
    NSString *Desscription = @"";
    int lastScore = [self.game lastScore];
    NSString *matchedCardsAsString = [[self.game lastMatch] componentsJoinedByString:@" & "];
    Card* lastCard = [self.game lastCard];
    
    if (matchedCardsAsString) {
        if (lastScore > 0) {
            Desscription = [NSString stringWithFormat:@"Matched %@ for %d points", matchedCardsAsString, lastScore];
        } else if (lastScore <= 0) {
            if (lastScore < 0) {
                Desscription = [NSString stringWithFormat:@"%@ don't match! %d point penalty!", matchedCardsAsString, -lastScore];
            } else if (lastScore == 0) {
                Desscription = [NSString stringWithFormat:@"%@ don't match!", matchedCardsAsString];
            }
        }
    } else {
        if (lastCard) {
            Desscription = [NSString stringWithFormat:@"Flipped up %@", lastCard];
        } else {
            Desscription = @"Touch to start!";
        }
    }
    
    return Desscription;
}

- (void)updateDesscription {
    self.currentDesscription = [self getDesscriptionForCurrentGame];
}

- (void)updateUI {
    [self updateDesscription];
    [self updateButtonsAndLabels];
}

-(void)setFlipCount:(int)flipCount {
    _flipCount = flipCount;
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d", self.flipCount];
}

- (IBAction)flipCard:(UIButton *)sender {    
    [self.game flipCardAtIndex:[self.cardButtons indexOfObject:sender]];
    self.flipCount++;
    [self updateUI];
    [self.cardGameScore recordGameScore:self.game.score];
}

- (IBAction)dealGame {
    self.cardGameScore = nil;
    self.game = nil;
    self.flipCount = 0;
    [self updateUI];
}

@end
