//
//  TwoCardGameViewController.h
//  Matchismo II
//
//  Created by Doug Lewis on 3/13/2013.
//  Copyright (c) 2013 Twicecraft. All rights reserved.
//

#import "CardGameViewController.h"

@interface TwoCardGameViewController : CardGameViewController
@end
