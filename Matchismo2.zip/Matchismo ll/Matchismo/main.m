//
//  main.m
//  Matchismo
//
//  Created by Doug Lewis on 3/13/2013
//  Copyright (c) 2013 Twicecraft. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CardGameAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CardGameAppDelegate class]));
    }
}
